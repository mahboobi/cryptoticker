<?php

$lang['alpha_dash_space']	= "The %s field may only contain alpha-numeric characters, underscores, dashes and space.";
$lang['alpha_dashes']	= "The %s field may only contain alpha-numeric characters, and dashes.";
$lang['error_wrong_date'] = "Wrong date, please try again";
$lang['indian_mobile'] = "Not a valid indian mobile number";


?>